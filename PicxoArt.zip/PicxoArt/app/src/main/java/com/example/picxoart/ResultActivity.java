package com.example.picxoart;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.example.picxoart.databinding.ActivityResultBinding;

public class ResultActivity extends AppCompatActivity {
      ActivityResultBinding binding;
    //button social
    ImageView InstaBtn;
    ImageView facebookBtn;
    ImageView whatsappBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityResultBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        InstaBtn = findViewById(R.id.instagram);
        facebookBtn = findViewById(R.id.facebook);
        whatsappBtn = findViewById(R.id.whatsapp);

          getSupportActionBar().hide();

        binding.image.setImageURI(getIntent().getData());

        //implement button
        InstaBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://www.instagram.com/accounts/login/");
            }
        });
        facebookBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://www.facebook.com/");
            }
        });
        whatsappBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://play.google.com/store/apps/details?id=com.whatsapp&hl=en&gl=US");
            }
        });
    }

    private void gotoUrl(String s){
        Uri uri = Uri.parse(s);
        startActivity(new Intent(Intent.ACTION_VIEW,uri));

    }
}